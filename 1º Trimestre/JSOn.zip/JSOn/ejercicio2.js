let cadenaJSON = `{
    "nombre": "Antonio",
    "apellidos": "Villegas Arcos",
    "edad": 26,
    "ocupacion": "estudiante"
  }`;
  
  
  let objetoJSON = JSON.parse(cadenaJSON);
  
  console.log(objetoJSON);
  
  