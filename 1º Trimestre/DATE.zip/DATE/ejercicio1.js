let cumpleaños = new Date("1996-11-24T23:30:00");

console.log(cumpleaños);